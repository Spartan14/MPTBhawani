package com.rest.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rest.entity.OrderEntity;
import com.rest.exceptions.OrderNotFoundException;
import com.rest.exceptions.NoSuchOrderException;
import com.rest.model.Order;
import com.rest.repository.OrderRepository;

@Service
@Transactional
public class OrderService {
	@Autowired
	OrderRepository orderRepository;
	
	
	public String insertOrder(Order order) {
		OrderEntity entity =  new OrderEntity();
		entity.setQuantity(order.getQuantity());
		entity.setPrice(order.getPrice());
		entity.setAmount(order.getPrice()*75*order.getQuantity());
		entity.setCharges((order.getPrice()*75*order.getQuantity()*1.25)/100);
		orderRepository.saveAndFlush(entity);
		return "Order with Order id "+entity.getOrderId() + " added successfully";
    }
	public String removeOrder(int orderId) throws NoSuchOrderException{
		Optional<OrderEntity> opt=orderRepository.findById(orderId);
		if(opt.isPresent())
		 {
			OrderEntity ord=opt.get();
			orderRepository.delete(ord);
		 } 
		else {
			throw new NoSuchOrderException("Order with " + orderId + " does not exist");
		}
		return "Order details deleted successfully";
	}
	
	public Order findOrder(int orderId) throws NoSuchOrderException{
		Optional<OrderEntity> opt=orderRepository.findById(orderId);
		if(opt.isPresent()) {
			OrderEntity entity=opt.get();
			Order ord = new Order();
			ord.setOrderId(entity.getOrderId());
			ord.setQuantity(entity.getQuantity());
			ord.setPrice(entity.getPrice());
			ord.setAmount(entity.getAmount());
			ord.setCharges(entity.getCharges());
			return ord;
		}
		else {
			throw new NoSuchOrderException("Order with " + orderId + " does not exist");
		}
	}
	
	public List<Order> getOrders() throws OrderNotFoundException{
		List<OrderEntity> entityList= orderRepository.findAll();
		if(entityList.isEmpty() || entityList.size()==0) {
			throw new OrderNotFoundException("Order details does not exist");
		}
		List<Order>list = new ArrayList();
		for (OrderEntity entity : entityList) {
			Order ord = new Order();
			ord.setOrderId(entity.getOrderId());
			ord.setQuantity(entity.getQuantity());
			ord.setPrice(entity.getPrice());
			ord.setAmount(entity.getAmount());
			ord.setCharges(entity.getCharges());
			list.add(ord);
		}
		return list;
		
	}
	public String updateOrder(Integer orderId,Order ord) throws NoSuchOrderException{
		Optional<OrderEntity> opt=orderRepository.findById(orderId);
		if(opt.isPresent())
		 {
			OrderEntity entity=opt.get();
			entity.setQuantity(ord.getQuantity());
			entity.setPrice(ord.getPrice());
			entity.setAmount(ord.getPrice()*75*ord.getQuantity());
			entity.setCharges((ord.getPrice()*75*ord.getQuantity()*1.25)/100);
		 } 
		else {
			throw new NoSuchOrderException("Order with " + orderId + " does not exist");
		}
		return "Order details updated successfully";
	}


}
