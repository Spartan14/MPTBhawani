package com.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestProductOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestProductOrderApplication.class, args);
	}

}
