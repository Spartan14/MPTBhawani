package com.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rest.exceptions.OrderNotFoundException;
import com.rest.exceptions.NoSuchOrderException;
import com.rest.model.Order;

import com.rest.service.OrderService;

@RestController
public class OrderController {
	@Autowired
	OrderService service;
	
	@PostMapping(value="/orders")
	public ResponseEntity<String> addOrder(@RequestBody Order ord) {
		
		String response = service.insertOrder(ord);
		return ResponseEntity.ok(response);
	}
	@GetMapping(value="/orders")
	public ResponseEntity<List<Order>> getOrders() throws OrderNotFoundException{ 
		List<Order> ordList= service.getOrders();
		return ResponseEntity.ok(ordList);
	}
	@GetMapping(value="/orders/{orderId}")
	public ResponseEntity<Order> getOrder(@PathVariable("orderId") int orderId) throws NoSuchOrderException{ 
		Order ord= service.findOrder(orderId);
		return ResponseEntity.ok(ord);
	}
	
		@PutMapping(value = "/orders/{orderId}")
		public String updateOrder(@PathVariable("orderId") int orderId, @RequestBody Order order) throws NoSuchOrderException{
			return service.updateOrder(orderId, order);
		}
		
		@DeleteMapping(value = "/orders/{orderId}")
		public String deleteOrder(@PathVariable("orderId") int orderId) throws NoSuchOrderException {
			return service.removeOrder(orderId);
		}
		
	/*
	 * @GetMapping(value="/orders/{quantity}") public ResponseEntity<Order>
	 * getOrderQuantity(@PathVariable("quantity") int quantity) throws
	 * NoSuchOrderException{ Order ord= service.findOrderQuantity(quantity); return
	 * ResponseEntity.ok(ord); }
	 * 
	 * @GetMapping(value="/orders/{amount}") public ResponseEntity<Order>
	 * getOrderAmount(@PathVariable("amount") int amount) throws
	 * NoSuchOrderException{ Order ord= service.findOrderQuantity(amount); return
	 * ResponseEntity.ok(ord); }
	 */
	
}
