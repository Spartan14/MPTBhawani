package com.rest.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class OrderNotFoundException extends Exception{
	
	public OrderNotFoundException() {
		super();
	}
	public OrderNotFoundException(String errors) {
		super(errors);
	}

}
